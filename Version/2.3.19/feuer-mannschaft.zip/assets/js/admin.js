document.addEventListener('DOMContentLoaded', function () {
    var adminData = window.feuerMannschaftAdminData || {};
    var firstName = document.getElementById('feuer_mannschaft_first_name');
    var lastName = document.getElementById('feuer_mannschaft_last_name');
    var titleInput = document.getElementById('title');
    var isProfileList = document.body.classList.contains('feuer-mannschaft-profile-list');
    var addNewLink = document.querySelector('.page-title-action');
    var postsFilter = document.getElementById('posts-filter');

    if (isProfileList && addNewLink && adminData.addNewUrl) {
        addNewLink.href = adminData.addNewUrl;
    }

    if (isProfileList && postsFilter && !postsFilter.querySelector('input[name="feuer_mannschaft_profile"]')) {
        var hiddenProfile = document.createElement('input');
        hiddenProfile.type = 'hidden';
        hiddenProfile.name = 'feuer_mannschaft_profile';
        hiddenProfile.value = '1';
        postsFilter.appendChild(hiddenProfile);
    }

    if (firstName && lastName && titleInput) {
        var syncTitle = function () {
            var fullName = [firstName.value, lastName.value].join(' ').trim();

            if (!fullName) {
                return;
            }

            titleInput.value = fullName;
        };

        firstName.addEventListener('input', syncTitle);
        lastName.addEventListener('input', syncTitle);
        syncTitle();
    }

    var createRepeaterRow = function (repeater) {
        var row = document.createElement('div');
        var input = document.createElement('input');
        var removeButton = document.createElement('button');

        row.className = 'feuer-mannschaft-repeater-row';
        row.setAttribute('data-repeater-row', '');

        input.type = 'text';
        input.className = 'widefat';
        input.name = repeater.getAttribute('data-repeater-name') || '';
        input.placeholder = repeater.getAttribute('data-repeater-placeholder') || '';

        removeButton.type = 'button';
        removeButton.className = 'button button-link-delete';
        removeButton.setAttribute('data-repeater-remove', '');
        removeButton.textContent = 'Entfernen';

        row.appendChild(input);
        row.appendChild(removeButton);

        return row;
    };

    document.querySelectorAll('[data-repeater]').forEach(function (repeater) {
        var rowsContainer = repeater.querySelector('[data-repeater-rows]');
        var addButton = repeater.querySelector('[data-repeater-add]');

        if (!rowsContainer || !addButton) {
            return;
        }

        var ensureEmptyRow = function () {
            if (!rowsContainer.querySelector('[data-repeater-row]')) {
                rowsContainer.appendChild(createRepeaterRow(repeater));
            }
        };

        addButton.addEventListener('click', function () {
            var row = createRepeaterRow(repeater);
            rowsContainer.appendChild(row);

            var input = row.querySelector('input');
            if (input) {
                input.focus();
            }
        });

        repeater.addEventListener('click', function (event) {
            var removeButton = event.target.closest('[data-repeater-remove]');

            if (!removeButton) {
                return;
            }

            var row = removeButton.closest('[data-repeater-row]');

            if (row) {
                row.remove();
            }

            ensureEmptyRow();
        });

        ensureEmptyRow();
    });

    document.querySelectorAll('input[data-switch-exclusive]').forEach(function (input) {
        input.addEventListener('change', function () {
            if (!input.checked) {
                return;
            }

            var groupName = input.getAttribute('data-switch-exclusive');

            document.querySelectorAll('input[data-switch-exclusive="' + groupName + '"]').forEach(function (otherInput) {
                if (otherInput !== input) {
                    otherInput.checked = false;
                }
            });
        });
    });

    var defaultImagePicker = document.querySelector('[data-feuer-mannschaft-default-image-picker]');
    var defaultImageTexts = adminData.defaultProfileImage || null;

    if (defaultImagePicker && defaultImageTexts && window.wp && wp.media) {
        var defaultImageInput = defaultImagePicker.querySelector('[data-default-image-input]');
        var defaultImagePreview = defaultImagePicker.querySelector('[data-default-image-preview]');
        var defaultImageSelect = defaultImagePicker.querySelector('[data-default-image-select]');
        var defaultImageRemove = defaultImagePicker.querySelector('[data-default-image-remove]');
        var mediaFrame = null;

        var clearNode = function (node) {
            while (node && node.firstChild) {
                node.removeChild(node.firstChild);
            }
        };

        var renderEmptyPreview = function () {
            if (!defaultImagePreview) {
                return;
            }

            clearNode(defaultImagePreview);

            var text = document.createElement('p');
            text.className = 'description';
            text.textContent = defaultImageTexts.emptyNotice || 'Noch kein Standardfoto ausgewaehlt.';
            defaultImagePreview.appendChild(text);
        };

        var renderImagePreview = function (attachment) {
            if (!defaultImagePreview) {
                return;
            }

            clearNode(defaultImagePreview);

            var image = document.createElement('img');
            var sizes = attachment && attachment.sizes ? attachment.sizes : {};
            var source = '';

            if (sizes.medium_large && sizes.medium_large.url) {
                source = sizes.medium_large.url;
            } else if (sizes.medium && sizes.medium.url) {
                source = sizes.medium.url;
            } else if (sizes.thumbnail && sizes.thumbnail.url) {
                source = sizes.thumbnail.url;
            } else if (attachment && attachment.url) {
                source = attachment.url;
            }

            if (!source) {
                renderEmptyPreview();
                return;
            }

            image.src = source;
            image.alt = attachment.alt || attachment.title || '';
            image.className = 'feuer-mannschaft-default-image-preview-image';
            defaultImagePreview.appendChild(image);
        };

        var syncDefaultImageButtons = function () {
            var hasImage = defaultImageInput && defaultImageInput.value;

            if (defaultImageSelect) {
                defaultImageSelect.textContent = hasImage
                    ? (defaultImageTexts.replaceLabel || 'Standardfoto ersetzen')
                    : (defaultImageTexts.chooseLabel || 'Standardfoto auswaehlen');
            }

            if (defaultImageRemove) {
                defaultImageRemove.disabled = !hasImage;
            }
        };

        if (defaultImageSelect && defaultImageInput) {
            defaultImageSelect.addEventListener('click', function () {
                if (!mediaFrame) {
                    mediaFrame = wp.media({
                        title: defaultImageTexts.frameTitle || 'Standardfoto auswaehlen',
                        button: {
                            text: defaultImageTexts.frameButton || 'Dieses Foto verwenden'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                    mediaFrame.on('select', function () {
                        var attachment = mediaFrame.state().get('selection').first().toJSON();

                        defaultImageInput.value = attachment.id || '';
                        renderImagePreview(attachment);
                        syncDefaultImageButtons();
                    });
                }

                mediaFrame.open();
            });
        }

        if (defaultImageRemove && defaultImageInput) {
            defaultImageRemove.addEventListener('click', function () {
                defaultImageInput.value = '';
                renderEmptyPreview();
                syncDefaultImageButtons();
            });
        }

        syncDefaultImageButtons();
    }

    var mentionsData = adminData.mentions || null;
    var mentionHelper = document.querySelector('[data-feuer-mannschaft-mention-helper]');

    if (!mentionsData || !mentionHelper) {
        return;
    }

    var mentionMembers = mentionsData.members || {};
    var mentionTexts = mentionsData.texts || {};
    var emptyNode = mentionHelper.querySelector('.feuer-mannschaft-mention-helper-empty');
    var listNode = mentionHelper.querySelector('.feuer-mannschaft-mention-shortcode-list');

    var getUniqueIds = function (values) {
        var unique = [];

        values.forEach(function (value) {
            var normalized = String(value || '').trim();

            if (!/^\d+$/.test(normalized) || unique.indexOf(normalized) !== -1) {
                return;
            }

            unique.push(normalized);
        });

        return unique;
    };

    var getSelectedMentionIds = function () {
        var fallbackSelect = document.querySelector('select[name="mentioned_persons[]"]');

        if (fallbackSelect) {
            return getUniqueIds(Array.prototype.map.call(fallbackSelect.selectedOptions || [], function (option) {
                return option.value;
            }));
        }

        var acfField = document.querySelector('.acf-field[data-name="mentioned_persons"]');

        if (!acfField) {
            return [];
        }

        var selectedItems = acfField.querySelectorAll('.values [data-id]');

        if (selectedItems.length) {
            return getUniqueIds(Array.prototype.map.call(selectedItems, function (item) {
                return item.getAttribute('data-id');
            }));
        }

        return getUniqueIds(Array.prototype.map.call(acfField.querySelectorAll('input[type="hidden"]'), function (input) {
            return input.value;
        }));
    };

    var selectInputText = function (input) {
        input.focus();
        input.select();
        input.setSelectionRange(0, input.value.length);
    };

    var copyText = function (text, input) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }

        return new Promise(function (resolve, reject) {
            try {
                if (input) {
                    selectInputText(input);
                }

                if (document.execCommand('copy')) {
                    resolve();
                    return;
                }
            } catch (error) {
                reject(error);
                return;
            }

            reject(new Error('copy_failed'));
        });
    };

    var insertShortcodeIntoEditor = function (shortcode) {
        if (window.wp && wp.data && wp.blocks && wp.blocks.createBlock) {
            var blockDispatcher = wp.data.dispatch('core/block-editor');

            if (blockDispatcher && typeof blockDispatcher.insertBlocks === 'function') {
                blockDispatcher.insertBlocks(wp.blocks.createBlock('core/shortcode', {
                    text: shortcode
                }));

                return true;
            }
        }

        var classicEditor = document.getElementById('content');

        if (!classicEditor) {
            return false;
        }

        var start = typeof classicEditor.selectionStart === 'number' ? classicEditor.selectionStart : classicEditor.value.length;
        var end = typeof classicEditor.selectionEnd === 'number' ? classicEditor.selectionEnd : classicEditor.value.length;
        var before = classicEditor.value.slice(0, start);
        var after = classicEditor.value.slice(end);
        var spacerBefore = before && !/\s$/.test(before) ? ' ' : '';
        var spacerAfter = after && !/^\s/.test(after) ? ' ' : '';

        classicEditor.value = before + spacerBefore + shortcode + spacerAfter + after;
        classicEditor.focus();

        var caret = (before + spacerBefore + shortcode).length;

        if (typeof classicEditor.setSelectionRange === 'function') {
            classicEditor.setSelectionRange(caret, caret);
        }

        return true;
    };

    var flashButtonLabel = function (button, text) {
        var originalText = button.getAttribute('data-original-text') || button.textContent;

        button.setAttribute('data-original-text', originalText);
        button.textContent = text;

        window.setTimeout(function () {
            button.textContent = originalText;
        }, 1200);
    };

    var createMentionItem = function (member) {
        var item = document.createElement('article');
        var top = document.createElement('div');
        var strong = document.createElement('strong');
        var openLink = document.createElement('a');
        var preview = document.createElement('div');
        var previewLabel = document.createElement('span');
        var previewLink = document.createElement('a');
        var shortcodeLabel = document.createElement('label');
        var actions = document.createElement('div');
        var input = document.createElement('input');
        var copyButton = document.createElement('button');
        var insertButton = document.createElement('button');

        item.className = 'feuer-mannschaft-mention-shortcode-item';
        top.className = 'feuer-mannschaft-mention-shortcode-top';
        preview.className = 'feuer-mannschaft-mention-shortcode-preview';
        previewLabel.className = 'feuer-mannschaft-mention-shortcode-label';
        actions.className = 'feuer-mannschaft-mention-shortcode-actions';

        strong.textContent = member.name;

        openLink.href = member.url;
        openLink.target = '_blank';
        openLink.rel = 'noopener noreferrer';
        openLink.textContent = mentionTexts.openProfile || 'Profil öffnen';

        previewLabel.textContent = (mentionTexts.preview || 'Vorschau') + ':';

        previewLink.href = member.url;
        previewLink.target = '_blank';
        previewLink.rel = 'noopener noreferrer';
        previewLink.textContent = member.name;

        shortcodeLabel.className = 'feuer-mannschaft-mention-shortcode-label';
        shortcodeLabel.textContent = mentionTexts.shortcode || 'Kurzcode';
        shortcodeLabel.setAttribute('for', 'feuer-mannschaft-mention-shortcode-' + member.id);

        input.type = 'text';
        input.readOnly = true;
        input.className = 'widefat';
        input.id = 'feuer-mannschaft-mention-shortcode-' + member.id;
        input.value = member.shortcode;

        copyButton.type = 'button';
        copyButton.className = 'button button-secondary';
        copyButton.textContent = mentionTexts.copy || 'Kopieren';
        copyButton.addEventListener('click', function () {
            copyText(member.shortcode, input).then(function () {
                flashButtonLabel(copyButton, mentionTexts.copied || 'Kopiert');
            }).catch(function () {
                selectInputText(input);
            });
        });

        insertButton.type = 'button';
        insertButton.className = 'button button-secondary';
        insertButton.textContent = mentionTexts.insert || 'Einfügen';
        insertButton.addEventListener('click', function () {
            if (insertShortcodeIntoEditor(member.shortcode)) {
                flashButtonLabel(insertButton, mentionTexts.inserted || 'Eingefügt');
                return;
            }

            copyText(member.shortcode, input).then(function () {
                flashButtonLabel(insertButton, mentionTexts.copied || 'Kopiert');
            }).catch(function () {
                flashButtonLabel(insertButton, mentionTexts.insertFailed || 'Bitte den Kurzcode manuell kopieren.');
                selectInputText(input);
            });
        });

        top.appendChild(strong);
        top.appendChild(openLink);
        preview.appendChild(previewLabel);
        preview.appendChild(previewLink);
        actions.appendChild(input);
        actions.appendChild(copyButton);
        actions.appendChild(insertButton);

        item.appendChild(top);
        item.appendChild(preview);
        item.appendChild(shortcodeLabel);
        item.appendChild(actions);

        return item;
    };

    var renderMentionHelper = function () {
        var selectedIds = getSelectedMentionIds();

        if (!listNode || !emptyNode) {
            return;
        }

        listNode.innerHTML = '';

        if (!selectedIds.length) {
            emptyNode.hidden = false;
            listNode.hidden = true;
            emptyNode.textContent = mentionTexts.empty || 'Wählen Sie zuerst eine oder mehrere erwähnte Personen aus.';
            return;
        }

        selectedIds.forEach(function (id) {
            if (!mentionMembers[id]) {
                return;
            }

            listNode.appendChild(createMentionItem(mentionMembers[id]));
        });

        var hasItems = !!listNode.children.length;

        emptyNode.hidden = hasItems;
        listNode.hidden = !hasItems;

        if (!hasItems) {
            emptyNode.textContent = mentionTexts.empty || 'Wählen Sie zuerst eine oder mehrere erwähnte Personen aus.';
        }
    };

    var refreshMentionHelper = function () {
        window.requestAnimationFrame(renderMentionHelper);
    };

    var fallbackSelect = document.querySelector('select[name="mentioned_persons[]"]');

    if (fallbackSelect) {
        fallbackSelect.addEventListener('change', refreshMentionHelper);
    }

    var acfField = document.querySelector('.acf-field[data-name="mentioned_persons"]');

    if (acfField && typeof MutationObserver === 'function') {
        var observer = new MutationObserver(refreshMentionHelper);
        observer.observe(acfField, {
            childList: true,
            subtree: true,
            attributes: true
        });

        acfField.addEventListener('change', refreshMentionHelper);
        acfField.addEventListener('click', function () {
            window.setTimeout(refreshMentionHelper, 60);
        });
    }

    renderMentionHelper();
});
