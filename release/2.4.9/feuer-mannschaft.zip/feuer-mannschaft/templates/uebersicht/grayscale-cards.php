<?php
/**
 * Template Name: Graustufen-Karten
 * Beschreibung: Kartenlayout mit ausgeblichenen Portraits und einstellbarer Graustufe.
 */

if (! defined('ABSPATH')) {
    exit;
}
?>
<div class="container py-5 feuer-mannschaft-archive-page <?php echo esc_attr($card_display_classes); ?> feuer-mannschaft-template-grayscale-cards" data-feuer-mannschaft-archive-url="<?php echo esc_url($this->get_current_url_without_filter()); ?>">
    <?php if (! empty($title) || ! empty($description)) : ?>
        <header class="feuer-mannschaft-grayscale-hero">
            <span class="feuer-mannschaft-grayscale-kicker">Mannschaft</span>
            <?php if (! empty($title)) : ?>
                <h1 class="mb-2"><?php echo esc_html($title); ?></h1>
            <?php endif; ?>
            <?php if (! empty($description)) : ?>
                <p class="text-muted mb-0"><?php echo esc_html($description); ?></p>
            <?php endif; ?>
        </header>
    <?php endif; ?>

    <?php if ($query->have_posts()) : ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
            <?php while ($query->have_posts()) : ?>
                <?php
                $query->the_post();
                echo $this->get_archive_grid_markup(get_the_ID(), 'standard', $single_template); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>
            <?php endwhile; ?>
        </div>
    <?php else : ?>
        <div class="alert alert-warning mb-0">
            Keine aktiven Mannschaftsmitglieder gefunden.
        </div>
    <?php endif; ?>
</div>
